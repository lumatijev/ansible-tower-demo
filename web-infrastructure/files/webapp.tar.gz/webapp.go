package main

import (
	"html/template"
	"log"
	"net/http"
	"os"
)

type Todo struct {
	Task string
	Done bool
}

var tmpls = template.Must(template.ParseFiles("tmpl/index.html"))

var todos = map[string]Todo{
	"intro":   {"Intro", true},
	"general": {"General talk", true},
	"demo":    {"Demo", false},
}

func main() {

	fs := http.FileServer(http.Dir("static/"))

	http.HandleFunc("/", logging(todosHandler))
	http.Handle("/static/", http.StripPrefix("/static/", fs))

	http.ListenAndServe(":8080", nil)
}

func logging(f http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Println(r.URL.Path)
		f(w, r)
	}
}

func todosHandler(w http.ResponseWriter, r *http.Request) {
	hostname, _ := os.Hostname()

	tmpls.ExecuteTemplate(w, "index.html", hostname)
}
